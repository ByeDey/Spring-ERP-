<%@ page language="java" contentType="text/html; charset=UTF-8"	
    pageEncoding="UTF-8"%>

<%
response.sendRedirect("lsh_login.erp");
%>